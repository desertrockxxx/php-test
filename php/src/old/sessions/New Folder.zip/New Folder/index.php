<html>
<head>
   
</head>
<body>
<form action="login.php" method="post">
Dein Name: <br />
<input type="Text" name="name" />
<input type="Submit" />
</form>   
</body>
</html>